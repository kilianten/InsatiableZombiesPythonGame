<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="Spritesheet" tilewidth="64" tileheight="64" tilecount="400" columns="20">
 <image source="Spritesheet.png" width="1280" height="1280"/>
</tileset>
